// Orders management functionality
document.addEventListener('DOMContentLoaded', function() {
    console.log('📋 Orders JS loaded');
    
    // Set default date to today for new orders
    const orderDateInput = document.getElementById('orderDate');
    if (orderDateInput) {
        const today = new Date().toISOString().split('T')[0];
        orderDateInput.value = today;
    }
});

// Search functionality
function searchOrders() {
    const searchTerm = document.getElementById('searchInput').value.toLowerCase();
    const orderCards = document.querySelectorAll('.order-card');
    
    orderCards.forEach(card => {
        const searchText = card.getAttribute('data-search-text');
        if (searchText && searchText.includes(searchTerm)) {
            card.style.display = 'block';
        } else {
            card.style.display = 'none';
        }
    });
}

// Open add modal
function openAddModal() {
    console.log('➕ Opening add modal');
    
    // Reset form
    document.getElementById('orderForm').reset();
    
    // Set modal title and action
    document.getElementById('orderModalTitle').innerHTML = '<i class="fas fa-plus me-2"></i>Add New Order';
    document.getElementById('orderAction').value = 'add';
    document.getElementById('orderSubmitBtn').innerHTML = '<i class="fas fa-save me-2"></i>Save Order';
    
    // Set default date
    const today = new Date().toISOString().split('T')[0];
    document.getElementById('orderDate').value = today;
    
    // Clear order ID
    document.getElementById('orderIdInput').value = '';
}

// Edit order function
function editOrder(orderId, customerName, assetName, orderDate, orderReal, orderIen, freteBrasil, freteJp, totalValue, deliveryDate, paymentType) {
    console.log('✏️ Editing order:', orderId, 'Asset:', assetName);
    
    // Set modal title and action
    document.getElementById('orderModalTitle').innerHTML = '<i class="fas fa-edit me-2"></i>Edit Order';
    document.getElementById('orderAction').value = 'edit';
    document.getElementById('orderSubmitBtn').innerHTML = '<i class="fas fa-save me-2"></i>Update Order';
    
    // Populate form fields
    document.getElementById('orderIdInput').value = orderId;
    
    // Handle customer input
    const customerInput = document.getElementById('orderCustomerName');
    if (customerInput && customerName) {
        customerInput.value = customerName;
        console.log('Set customer value to:', customerName);
    }

    // Handle asset input
    const assetInput = document.getElementById('orderAssetName');
    if (assetInput && assetName) {
        assetInput.value = assetName;
        console.log('Set asset value to:', assetName);
    }
    
    // Format date properly for HTML date input (YYYY-MM-DD)
    let formattedDate = '';
    if (orderDate) {
        // Check if date is in MM/DD/YYYY format and convert to YYYY-MM-DD
        if (orderDate.includes('/')) {
            const parts = orderDate.split('/');
            if (parts.length === 3) {
                formattedDate = `${parts[2]}-${parts[0].padStart(2, '0')}-${parts[1].padStart(2, '0')}`;
            }
        } else if (orderDate.includes('-')) {
            formattedDate = orderDate; // Already in YYYY-MM-DD format
        }
    }
    
    // Set all other field values
    document.getElementById('orderDate').value = formattedDate;
    document.getElementById('orderReal').value = orderReal || '';
    document.getElementById('orderIen').value = orderIen || '';
    document.getElementById('freteBrasil').value = freteBrasil || '';
    document.getElementById('freteJp').value = freteJp || '';
    document.getElementById('totalValue').value = totalValue || '';
    document.getElementById('deliveryDate').value = deliveryDate || '';
    document.getElementById('paymentType').value = paymentType || '';
    
    console.log('✅ All fields populated');
}

// Delete order function
function deleteOrder(orderId, customerName) {
    console.log('🗑️ Deleting order:', orderId);
    
    // Set form data
    document.getElementById('deleteOrderId').value = orderId;
    document.getElementById('deleteOrderCustomer').textContent = customerName || 'Unknown Customer';
    
    // Show the modal
    const deleteModal = new bootstrap.Modal(document.getElementById('deleteOrderModal'));
    deleteModal.show();
}

// Switch to calculator tab
function switchToCalculator() {
    console.log('🧮 Switching to calculator tab');
    const calculatorTab = document.getElementById('calculator-tab');
    if (calculatorTab) {
        calculatorTab.click();
    }
}

// Switch to orders tab  
function switchToOrders() {
    console.log('📋 Switching to orders tab');
    const ordersTab = document.getElementById('orders-tab');
    if (ordersTab) {
        ordersTab.click();
    }
}

// Function to refresh orders data
async function refreshOrdersData() {
    try {
        // Reload the page to refresh orders data
        window.location.reload();
    } catch (error) {
        console.error('Error refreshing orders:', error);
    }
}

// Make it globally available
window.refreshOrdersData = refreshOrdersData;

// Add event listener for edit buttons
document.addEventListener('click', function(e) {
    if (e.target.closest('.btn-edit')) {
        const btn = e.target.closest('.btn-edit');
        const orderId = btn.dataset.orderId;
        const customerName = btn.dataset.customerName;
        const assetName = btn.dataset.assetName;
        const orderDate = btn.dataset.orderDate;
        const orderReal = btn.dataset.orderReal;
        const orderIen = btn.dataset.orderIen;
        const freteBrasil = btn.dataset.freteBrasil;
        const freteJp = btn.dataset.freteJp;
        const totalValue = btn.dataset.totalValue;
        const deliveryDate = btn.dataset.deliveryDate;
        const paymentType = btn.dataset.paymentType;
        
        editOrder(orderId, customerName, assetName, orderDate, orderReal, orderIen, freteBrasil, freteJp, totalValue, deliveryDate, paymentType);
    }
});

// Batch selection functionality
document.addEventListener('DOMContentLoaded', function() {
    // Initialize checkbox event listeners
    initializeBatchSelection();
});

function initializeBatchSelection() {
    // Listen for checkbox changes
    document.addEventListener('change', function(e) {
        if (e.target.classList.contains('order-select-checkbox')) {
            updateBatchControls();
        }
    });

    // Batch edit button
    document.getElementById('batchEditBtn')?.addEventListener('click', openBatchEditModal);
    
    // Clear selection button
    document.getElementById('clearSelectionBtn')?.addEventListener('click', clearAllSelections);
}

function updateBatchControls() {
    const checkboxes = document.querySelectorAll('.order-select-checkbox');
    const checkedBoxes = document.querySelectorAll('.order-select-checkbox:checked');
    const batchControls = document.getElementById('batchControls');
    const selectedCount = document.getElementById('selectedCount');
    
    if (checkedBoxes.length > 0) {
        batchControls.style.display = 'block';
        selectedCount.textContent = checkedBoxes.length;
    } else {
        batchControls.style.display = 'none';
    }
}

function clearAllSelections() {
    const checkboxes = document.querySelectorAll('.order-select-checkbox:checked');
    checkboxes.forEach(checkbox => checkbox.checked = false);
    updateBatchControls();
}

function openBatchEditModal() {
    const checkedBoxes = document.querySelectorAll('.order-select-checkbox:checked');
    if (checkedBoxes.length === 0) return;
    
    // Collect order IDs
    const orderIds = Array.from(checkedBoxes).map(checkbox => checkbox.dataset.orderId);
    
    // Update modal content
    document.getElementById('batchOrderCount').textContent = checkedBoxes.length;
    document.getElementById('batchOrderIds').value = orderIds.join(',');
    
    // Reset form fields
    document.getElementById('batchDeliveryDate').value = '';
    document.getElementById('batchPaymentType').value = '';
    
    // Show modal
    const batchModal = new bootstrap.Modal(document.getElementById('batchEditModal'));
    batchModal.show();
}
